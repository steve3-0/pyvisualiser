"""
    Audio Visualiser programme based on preDAC recorder
    this is a sandpit environment to create ideas for use on preDAC
    but using pygame as a renderer to test on Mac OS

    This version aims to simulate the new display and create a range of visually appealing spectrum
    analysers:  Variables to experiment:
        - smoothing
        - decay profiles
        - peak profiles
        - bars made of rectangles

"""
from    processaudio import AudioProcessor
from    roon import Roon
from    displaydriver import GraphicsDriver
from    screens import *
from    events import Events
from    framecore import ListNext
import  time
from    pygame.locals import *   # this pulls down all the K_* constants



FPS    = 60

""" Use this sub class the either stub out or setup the metadata source """
class MetaData(Roon):
    pass

""" HW Platform providing display, audio and physical controls """
class Platform(AudioProcessor, MetaData, GraphicsDriver):
    def __init__(self, events):
        GraphicsDriver.__init__(self, events, FPS)
        AudioProcessor.__init__(self, events, device="loopin")
        MetaData.__init__(self, events, maxwh=self.wh, target_name='pre3')


    def stop(self):
        self.graphics_end()
        self.stop_capture()
        self.metadata_stop()


""" Event processor """
class Controller:
    def __init__(self):

        self.events         = Events(( 'Audio', 'KeyPress', 'Metadata'))
        self.platform       = Platform(self.events)

        """ Setup the event callbacks """
        self.events.KeyPress  += self.KeyAction    # when the remote controller is pressed
        self.events.Audio     += self.AudioAction     # respond to a new sample, or audio silence
        self.events.Metadata  += self.MetadataAction     # respond to a new sample, or audio silence

        """Set up the screen for inital Mode"""
        self.baseScreen     = 'MetaVUScreen'
        self.preScreenSaver = self.baseScreen
        self.status         = 'running'
        self.track_rotate   = False

        """ Set up the screen objects to be used """
        self.screens    = {}  # dict for the screen objects
        self.screenList = { MetaVUScreen, BigDialsScreen, TrackSpectrumScreen4,TrackOscScreen, TrackScreen, TrackVUMeterScreen, TrackSpectrumScreen2, TrackSpectrumScreen, 
                           TrackVisScreen3, TrackVisScreen2, TrackVisScreen, TrackScreen, TrackSpectrumScreen, TrackVUMeterScreen, TrackVUMeterScreen2, TrackSpectrumScreen3, TrackVUMeterScreen2 }
            
            # TestVUMetersScreen, TestVUScreen,  }

            # TestScreen, TestVUImageScreen1, TestVisualiserScreen, TestVUMetersScreen, TestVUScreen, TestSpectrumScreen, TestScreen}#, TestVUScreen, TestVUImageScreen1, TestVUImageScreen2, TestVUMetersScreen, TestSpectrumScreen }

        """ Screen types are:   Control for utility messages like vol change,  Test to exercise functionality, Base for mixed visual displays """

        """ Menu functionality """
        self.menuMode = False
        menuSequence  = []

        for screen in self.screenList:
            self.screens.update( {screen.__name__ : screen(self.platform) })
            if screen.type != 'Control':  #ie create a menu from Test & Base screens
                menuSequence.append(screen.__name__)
        self.screenmenu = ListNext(menuSequence, self.baseScreen)
        # print("Controller.__init__> menus intialised", self.screenmenu)

    def setScreen(self, s):
        self.activeScreen = s
        print("Controller.setScreen> active screen is ", s)

    def startAction(self):
        self.setScreen(self.baseScreen)
        self.platform.start_capture()

    def stopAction(self):
        self.platform.stop()


    def AudioAction(self, e):
        if e == 'capture':
            if self.audioready>1:
                print("Controller.AudioAction> %d sample buffer underrun, dump old data " % self.audioready)
            self.platform.process()
            self.audioready +=1

        else:
            print("Controller.AudioAction> unprocessed event ",e)

    def KeyAction(self, key):
        if self.status == 'stopped':
            if key == K_RETURN:
                self.platform.start_capture()
                self.status = 'running'
            elif key == K_SPACE:
                self.status = 'exit'
            else:
                print("KeyAction ", key)
        elif self.status == 'running':
            if key == K_RETURN:
                self.platform.stop_capture()
                self.status = 'stopped'
            elif key == K_SPACE:
                self.status = 'exit'

            elif key == K_LEFT:
                self.baseScreen   = self.screenmenu.next
                self.setScreen(self.baseScreen)

            elif key == K_RIGHT:
                self.baseScreen   = self.screenmenu.prev
                self.setScreen(self.baseScreen)

            elif key == 114:  #R key pressed
                self.track_rotate = not self.track_rotate
                print("Controller.KeyAction> R: track screen rotate", self.track_rotate)

            elif key == K_UP:
                print("Controller.KeyAction> UP: screen variant scrolling not implemented")
            elif key == K_DOWN:
                print("Controller.KeyAction> DOWN: screen variant scrolling not implemented")
            else:
                print("Controller.KeyAction: Key Press ", key)
        else:
            print("Controller.KeyAction> unknown event ",key)

    def MetadataAction(self, key):
        print("Controller.RoonAction> event ", key)
        if key == 'start':
            print("Controller.RoonAction> track started")

        elif key == 'new_track':
            print("Controller.RoonAction> new track - pop up display ", key)
            if self.track_rotate:    
                self.baseScreen   = self.screenmenu.next
                self.setScreen(self.baseScreen)  
            # self.trackChangeTimer.start()
            # self.activeScreen= 'trackChange'

        elif key == 'stop':
            print("Controller.RoonAction> track stopped - display nothing new")
            # self.platform.clear_track()

        elif key =='trackNotified':
            print("Controller.RoonAction> track notification timeout")
            # self.activeScreen= self.baseScreen

        else:
            print("Controller.RoonAction> unknown event ", key)


    """ Main execution loop """
    def run(self):
        self.startAction()
        self.audioready = 0
        print("Controller.run> startup configured")
        t = time.time()
        loop_count = 0

        # main loop
        while(self.status != 'exit'):
            self.platform.checkKeys()

            if self.platform.audio_available:
                # instument the real-time audio processing to see where the time bottlenecks are
                start_time = time.perf_counter()

                # perform the audio processing
                self.platform.process() 
                self.platform.data_available = False # Reset the flag
                self.audioready = 0
                processing_time_ms = (time.perf_counter() - start_time) * 1000

                # build and update the display
                screen = self.screens[self.activeScreen]
                self.platform.draw_start(screen.title + " > " + type(screen).__name__)
                self.screens[self.activeScreen].draw()
                self.platform.draw_end()
                drawing_time_ms = (time.perf_counter() - start_time) * 1000

                # analyse the loop time, only display every 2 seconds       
                if loop_count % 20 == 0:
                    loop_time = processing_time_ms + drawing_time_ms
                    print("Controller.run> loop time: %.2f ms, audio processing %.2f ms, display drawing %.2f ms" % (loop_time, processing_time_ms, drawing_time_ms))
                    loop = 0
                loop_count += 1

                # print("run> waited for audio: waited", 1000*(time.time()-t))
                t = time.time()
            else:
                # print("run> waiting for audio: waited", 1000*(time.time()-t))
                time.sleep(1/FPS)

        self.stopAction()



if __name__ == "__main__":
    viz = Controller()
    try:
        viz.run()
    except KeyboardInterrupt:
        pass
