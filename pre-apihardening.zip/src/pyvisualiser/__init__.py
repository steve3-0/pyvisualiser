"""
PyVisualiser - Audio Visualization Library
==========================================

A high-performance GPU-accelerated audio visualization framework
supporting macOS desktop and embedded Raspberry Pi 5 preamplifiers.
"""

import sys
import warnings

# Suppress setuptools pkg_resources deprecation warnings from third-party libraries (pygame)
warnings.filterwarnings("ignore", category=UserWarning, message=".*pkg_resources is deprecated.*")

__version__ = "2.0.0"
__author__ = "Baloothebear4"

# Optional macOS platform extensions
if sys.platform == "darwin":
    try:
        import Cocoa  # noqa: F401
        import Quartz  # noqa: F401
    except ImportError:
        pass

# Core Subsystems
from .core.processaudio import AudioProcessor, AudioAnalyser
from .core.displaydriver import (
    GraphicsDriver,
    GraphicsDriverGL,
    GraphicsDriverPi,
    GraphicsDriverMac,
    GeometryPass,
)
from .core.components import (
    Frame,
    Bar,
    Image,
    Text,
    Box,
    Line,
    Outline,
    FontCacheManager,
)
from .core.framecore import Frame, ColFramer, RowFramer, ListNext, Colour, Cache, Smoother
from .core.screenhandler import ScreenController, Platform, EventHandler, HWInterface
from .core.render import RenderContext, RenderTarget, Compositor, RenderPass, BlurPass, CompositePass

# Visualiser Components
from .visualisers.vumeters import VUFrame, VUMeter, VU2chFrame, VU2chHorzFrame, VUFlipFrame, VUMeterImageFrame
from .visualisers.metadata import MetaDataFrame, MetaData, MetaImages, PlayProgressFrame, TextFrame, CircularProgress
from .visualisers.spectrum import SpectrumFrame, Spectrum, StereoSpectrumFrame, Diamondiser, Octaviser
from .visualisers.oscillogramme import Oscilogramme, OscilogrammeBar, SamplesFrame
from .visualisers.advanced_frames import EchoWaveFrame, KaleidoscopeFrame, PulseOrbFrame, SpectrumWaveFrame, FreqWaveFrame
from .visualisers.glvisualisers import Kalidoscope, SpectrumMesh
from .core.glwrapper import ShaderFrame, ShaderFrame, GLSLRenderPass

# Style System
# Style System & Presets
from .styles.styles import (
    BarStyle,
    BarEffects,
    SpectrumStyle,
    VUMeterStyle,
    VUNeedleStyle,
    VUMeterScale,
    BackgroundStyle,
    AmbientGlowStyle,
    ReactiveGlowStyle,
    PeakAccentStyle,
    StarfieldStyle,
    CloudStyle,
    EdgeLightStyle,
    OutlineStyle,
    TextStyle,
    ReflectionStyle,
    VignetteStyle,
    NoiseStyle,
    OscillogrammeStyle,
)
from .styles.presets import (
    EmbeddedHiFiProfile,
    DesktopWidgetProfile,
    LUXURY_PROFILE,
    NEON_PROFILE,
    MINIMAL_PROFILE,
    NeonGlow,
    StrongEffect,
    DreamEffect,
    BackgroundDefault,
    PaletteDefault,
    FullScale,
    OutlineDefault,
    Centred,
)
from .styles.profiles import ProfileManager, ProfileControls, ProfileController


def get_version() -> str:
    return __version__


__all__ = [
    "ScreenController",
    "Platform",
    "EventHandler",
    "HWInterface",
    "Frame",
    "ColFramer",
    "RowFramer",
    "ListNext",
    "Colour",
    "Cache",
    "Smoother",
    "Bar",
    "Text",
    "Image",
    "Box",
    "Line",
    "Outline",
    "FontCacheManager",
    "AudioProcessor",
    "AudioAnalyser",
    "GraphicsDriver",
    "GraphicsDriverGL",
    "GeometryPass",
    "RenderContext",
    "RenderTarget",
    "Compositor",
    "RenderPass",
    "BlurPass",
    "CompositePass",
    "VUFrame",
    "VUMeter",
    "VU2chFrame",
    "VU2chHorzFrame",
    "VUFlipFrame",
    "VUMeterImageFrame",
    "SpectrumFrame",
    "Spectrum",
    "StereoSpectrumFrame",
    "Diamondiser",
    "Octaviser",
    "Oscilogramme",
    "OscilogrammeBar",
    "SamplesFrame",
    "EchoWaveFrame",
    "KaleidoscopeFrame",
    "PulseOrbFrame",
    "SpectrumWaveFrame",
    "FreqWaveFrame",
    "Kalidoscope",
    "SpectrumMesh",
    "ShaderFrame",
    "MetaDataFrame",
    "MetaData",
    "MetaImages",
    "PlayProgressFrame",
    "TextFrame",
    "CircularProgress",
    "BarStyle",
    "BarEffects",
    "SpectrumStyle",
    "VUMeterStyle",
    "VUNeedleStyle",
    "VUMeterScale",
    "BackgroundStyle",
    "AmbientGlowStyle",
    "ReactiveGlowStyle",
    "PeakAccentStyle",
    "StarfieldStyle",
    "CloudStyle",
    "EdgeLightStyle",
    "OutlineStyle",
    "TextStyle",
    "ReflectionStyle",
    "VignetteStyle",
    "NoiseStyle",
    "OscillogrammeStyle",
    "EmbeddedHiFiProfile",
    "DesktopWidgetProfile",
    "LUXURY_PROFILE",
    "NEON_PROFILE",
    "MINIMAL_PROFILE",
    "NeonGlow",
    "ProfileManager",
    "ProfileControls",
    "ProfileController",
    "get_version",
]